
<!DOCTYPE html>
<html lang="en">
<head>
  <title>DR. VIJAYANT GOVINDA GUPTA </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="<?php echo e(config('app.url')); ?>/assets/images/contact-us-page-12-e1713074250371.webp" type="image/x-icon">
    <link rel="icon" href="<?php echo e(config('app.url')); ?>/assets/images/contact-us-page-12-e1713074250371.webp" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo e(config('app.url')); ?>/assets/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
    integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <style>
    .youn{
        display: none
    }
    .refresh{
        text-align: center;
            position: fixed;
    z-index: 1000;
    top: 50%;
    background: #000;
    border: 0;
    border-radius: 0;
    box-shadow: 1px 1px 6px #403d3d;
    }
  </style>
</head>
<body>

<div class="p-2 bg-primary text-white text-start d-none d-lg-block top-bar">
  <div class="container">
  <img decoding="async"
    src="<?php echo e(config('app.url')); ?>/assets/images/contact-us-page-12-e1713074250371.webp"
    class="logo" alt="">
</div>
</div>

<section>
<div class="container my-2 my-md-5 ">
  <div class="row">
    <div class="col-md-6 d-inline-flex align-items-center justify-content-center text-center">
      <div>

      <img decoding="async" src="<?php echo e(config('app.url')); ?>/assets/images/Dr.-Vineet-Govinda-Gupta-1024x1013.png" class="img-fluid drimage" alt="" style="    max-height: 200px;    margin: auto;
    display: block;">
      <h4 class="drName">DR. VIJAYANT GOVINDA GUPTA</h4>
      <p class="heading-title">Senior Consultant Urologist and Andrologist</p>
      <ul class="nav nav-pills d-flex justify-content-center social-links mb-5">
        <li class="facebook">
          <a  href="#"><i class="fab fa-facebook-f"></i></a>
        </li>
        <li class="instagram">
          <a href="#"><i class="fab fa-instagram"></i></a>
        </li>
        <li class="twitter">
          <a href="#"><i class="fab fa-twitter"></i></a>
        </li>
        <li class="linkedin">
          <a href="#"><i class="fab fa-linkedin"></i></a>
        </li>
        <li class="youtube">
          <a href="#"><i class="fab fa-youtube"></i></a>
        </li>
      </ul>
      </div>
    </div>
    <div class="col-md-6">

      <div class="d-flex justify-content-between py-2 px-4 bg-primary">

          <div class="dateTime">
              <h3 class="title">
                <span class=""><i class="fa fa-calendar"></i></span><span> <?php echo e(date('jS F Y')); ?></span>
              </h3>
          </div>
          <div class="dateTime">
            <h3 class="title">
              <span class=""><i class="fa fa-clock"></i></span><span>
              <?php echo e(date('g:i a')); ?> IST </span>
            </h3>



          </div>

      </div>


      

      <div class="dynamic_content">

        <?php if($data->status == 1): ?>

      <div class="d-flex justify-content-center py-2 px-4 bg-primary mt-3">

        <div class="cTime">
          <h3 class="title">
            CURRENT TOKEN NUMBER FOR OPD IS
          </h3>
        </div>


      </div>
      <div class="d-flex justify-content-center py-2 px-4  mt-3">

        <div class="cNumber">
          <h3 class="text-primary">
            0<?php echo e($data->curr_token); ?>

          </h3>
        </div>
      </div>
      <h5 class="text-center h6">NEXT NUMBER WILL COME WITHIN <?php echo e($data->avg_time_in_min); ?> MINUTES</h5>

      <div class="mt-5">
        <form class="form-checkTime">
          <div class="input-group">
            <input type="email" class="form-control" placeholder="Enter your token Number" id="MyToken">
            <span class="input-group-btn">
              <button class="btn" type="button" id="checkMyTime">check estimate time</button>
            </span>
          </div>
        </form>
      </div>


      <?php endif; ?>
      <?php if($data->status == 0): ?>

      <h4 class="text-center text-danger mt-5">
        Next OPD will be starts on <b><?php echo e(date('jS F Y',strtotime($data->start_from_date))); ?></b> from <b><?php echo e(date('g:i a',strtotime($data->start_from_time))); ?></b>

      </h4>

       <?php endif; ?>


<div class="youn">
    <div class="d-flex justify-content-center py-2 px-4 bg-primary mt-3">

        <div class="cTime">
          <h3 class="title">
      YOUR NUMBER WILL COME AFTER
          </h3>
        </div>


      </div>

      <div class="d-flex justify-content-evenly my-3 come-after ">

        <div class=" bg-primary p-3 text-center">
          <h3 class="title">
          <span class="myHr">0</span><br>
          HOURS
          </h3>
        </div>
        <div class=" bg-primary p-3 text-center">
          <h3 class="title">
            <span class="myMin">0</span><br>
            MINUTES
          </h3>



        </div>

      </div>
</div>
</div>


      


    </div>
  </div>
</div>
</section>

<div class="mt-5 p-4 bg-primary text-white text-start">
  <div class="container">
<p class="mb-0 ftext">Copyright © 2024 | Govinda Medicenter | All Rights Reserved
</p>
</div></div>


<a href="<?php echo e(url('/')); ?>" class="btn btn-primary refresh"><i class="fa fa-refresh"></i> <br> Refresh</a>



<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
    $( "#checkMyTime" ).click(function() {
  var token = $( "#MyToken" ).val();
  if(token == ''){
    alert('Please Enter Your Token Number');
    return false;
  }
  $.ajax({
         type:'POST',
         url:'<?php echo e(route('check_my_time')); ?>',
         data: {"token": token},
         headers: {
                            'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>",
                        },
         success:function(data){
            var data = $.parseJSON(data);
            if(data.status == 1){
               $(".youn").show();
                $(".myHr").html(data.hours);
                $(".myMin").html(data.minutes);
            }else{
                alert(data.messg);
            }
         }
      });

});
</script>
</body>
</html>
<?php /**PATH D:\php\freel\OPDtoken\resources\views/welcome.blade.php ENDPATH**/ ?>