<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Token_settings;

class VisitorController extends Controller
{

    public function index()
    {
        $data = Token_settings::latest()->first();
        return view('welcome', compact('data'));
    }
    public function check_my_time(Request $request)
    {
        $output = array();
        if($request->token !=''){
            $data = Token_settings::latest()->first();
            if($data->status==1){
                $ct = $data->curr_token;
                if($request->token<= $ct){
                    $output['messg'] = 'Your token number has expired';
                    $output['status'] = 0;
                }else{
                    $tt = $request->token - $ct;
                    $avg = $data->avg_time_in_min;
                    $tmin = round($tt * $avg);

                    $output['minutes'] = $tmin % 60;
                    $output['hours'] = intdiv($tmin, 60);
                    $output['status'] = 1;
                }
            }else{
                $output['messg'] = 'OPD Not Started';
                $output['status'] = 0;
            }

        }else{
            $output['messg'] = 'Token Required !!';
            $output['status'] = 0;
        }
        echo json_encode($output);
    }

}
