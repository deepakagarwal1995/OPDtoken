<?php

namespace App\Http\Controllers;

use App\Models\Token_settings;
use Illuminate\Http\Request;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $data = Token_settings::latest()->first();
        return view('home', compact('data'));
    }
    public function average_time(Request $request)
    {
        try {
            $request->validate([
                'avg_time_in_min' => 'required|numeric|min:1'
            ]);
            Token_settings::orderBy('id', 'desc')
            ->take(1)
            ->update(['avg_time_in_min' => $request->avg_time_in_min]);
            return redirect()->back()->with('success', 'Average Time Per Token Updated');
        } catch (\Exception $e) {

            $mssg =  $e->getMessage();
            return redirect()->back()->with('error', $mssg);
        }
    }
    public function start_opd(Request $request)
    {
        try {

            Token_settings::orderBy('id', 'desc')
            ->take(1)
                ->update(['status' => 1, 'curr_token'=> 1]);
            return redirect()->back()->with('success', 'OPD Status Updated');
        } catch (\Exception $e) {

            $mssg =  $e->getMessage();
            return redirect()->back()->with('error', $mssg);
        }
    }
    public function update_token(Request $request)
    {
        try {
            $request->validate([
                'curr_token' => 'required|numeric|min:1'
            ]);

            Token_settings::orderBy('id', 'desc')
            ->take(1)
                ->update(['curr_token' => $request->curr_token]);
            return redirect()->back()->with('success', 'Token Updated');
        } catch (\Exception $e) {

            $mssg =  $e->getMessage();
            return redirect()->back()->with('error', $mssg);
        }
    }
    public function stop_opd(Request $request)
    {
        try {
            $request->validate([
                'start_from_date' => 'required|date_format:Y-m-d|after_or_equal:today',
                'start_from_time' => 'required|date_format:H:i'
            ]);

            Token_settings::orderBy('id', 'desc')
            ->take(1)
                ->update(['start_from_date' => $request->start_from_date,'start_from_time' => $request->start_from_time, 'status' => 0]);
            return redirect()->back()->with('success', 'OPD Status Updated');
        } catch (\Exception $e) {

            $mssg =  $e->getMessage();
            return redirect()->back()->with('error', $mssg);
        }
    }

}
